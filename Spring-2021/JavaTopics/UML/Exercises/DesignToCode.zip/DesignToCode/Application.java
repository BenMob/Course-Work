package DesignToCode;

public class Application {

    public static void main(String[] args){
        System.out.println("Lab 2");
    }
}