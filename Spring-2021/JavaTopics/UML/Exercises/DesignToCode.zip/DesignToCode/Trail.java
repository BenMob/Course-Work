package DesignToCode;

public class Trail {

}