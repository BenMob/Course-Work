package DesignToCode;

public class Highway {

}