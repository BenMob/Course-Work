package DesignToCode;

public class Trip {

}