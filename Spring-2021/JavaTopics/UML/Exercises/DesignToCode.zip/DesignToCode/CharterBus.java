package DesignToCode;

public class CharterBus {

}