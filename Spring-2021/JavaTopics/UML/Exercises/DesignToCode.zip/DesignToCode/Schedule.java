package DesignToCode;

public class Schedule {

}