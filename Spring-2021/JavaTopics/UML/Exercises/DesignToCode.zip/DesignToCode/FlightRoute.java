package DesignToCode;

public class FlightRoute {

}