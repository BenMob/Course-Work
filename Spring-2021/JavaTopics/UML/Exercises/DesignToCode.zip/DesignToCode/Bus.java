package DesignToCode;

public class Bus {

}