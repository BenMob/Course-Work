package DesignToCode;

public class Airplane {

}