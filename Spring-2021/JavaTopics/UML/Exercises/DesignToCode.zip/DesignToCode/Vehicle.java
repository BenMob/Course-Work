package DesignToCode;

public class Vehicle {

}