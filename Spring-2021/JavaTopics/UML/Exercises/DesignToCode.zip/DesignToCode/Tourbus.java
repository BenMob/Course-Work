package DesignToCode;

public class Tourbus {

}