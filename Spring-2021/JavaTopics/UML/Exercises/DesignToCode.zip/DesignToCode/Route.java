package DesignToCode;

public class Route {

}