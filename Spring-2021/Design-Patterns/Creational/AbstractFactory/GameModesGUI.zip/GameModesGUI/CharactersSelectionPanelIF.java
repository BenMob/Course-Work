package GameModesGUI;

interface CharactersSelectionPanelIF{
    public void display();
}