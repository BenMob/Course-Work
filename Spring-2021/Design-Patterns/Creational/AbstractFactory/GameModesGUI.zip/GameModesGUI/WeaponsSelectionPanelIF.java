package GameModesGUI;

interface WeaponsSelectionPanelIF{
    public void display();
}