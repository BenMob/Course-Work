package AgentDemo;

public interface Agent_IF {
    void startTask();
    void stopTask();
    void setTaskID(int id);
}
