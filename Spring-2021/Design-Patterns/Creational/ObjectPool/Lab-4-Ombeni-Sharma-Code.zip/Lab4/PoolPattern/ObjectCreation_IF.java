package PoolPattern;

public interface ObjectCreation_IF {
    Object create();
}
